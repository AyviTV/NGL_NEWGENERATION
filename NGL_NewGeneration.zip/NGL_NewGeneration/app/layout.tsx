import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Secretly - Messages Anonymes",
  description: "Reçois des questions anonymes et partage tes réponses sur Snapchat !",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" className="dark">
      <body className="bg-neutral-950 text-white antialiased">
        {children}
      </body>
    </html>
  );
}
