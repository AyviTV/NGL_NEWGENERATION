'use client';

import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [messages, setMessages] = useState<any[]>([]);
  const [activeMessage, setActiveMessage] = useState<any>(null);
  const [replyText, setReplyText] = useState('');
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Écoute de l'état de connexion de l'utilisateur
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Chargement des messages de l'utilisateur connecté
  useEffect(() => {
    if (user) {
      fetchMessages();
    }
  }, [user]);

  const fetchMessages = async () => {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) console.error(error);
    if (data) setMessages(data);
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    const { error } = authMode === 'signup' 
      ? await supabase.auth.signUp({ email, password })
      : await supabase.auth.signInWithPassword({ email, password });
    
    if (error) {
      alert(error.message);
    }
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('messages').delete().eq('id', id);
    if (!error) {
      setMessages(messages.filter(m => m.id !== id));
      setActiveMessage(null);
    }
  };

  // Helper pour couper le texte proprement sur le Canvas Snapchat
  const wrapCanvasText = (ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number) => {
    const words = text.split(' ');
    let line = '';
    let currentY = y;

    for (let n = 0; n < words.length; n++) {
      let testLine = line + words[n] + ' ';
      let metrics = ctx.measureText(testLine);
      let testWidth = metrics.width;
      if (testWidth > maxWidth && n > 0) {
        ctx.fillText(line, x, currentY);
        line = words[n] + ' ';
        currentY += lineHeight;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, x, currentY);
  };

  // Générateur d'image au format Story Snapchat (1080x1920)
  const downloadSnapchatStory = () => {
    const canvas = canvasRef.current;
    if (!canvas || !activeMessage) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 1080;
    canvas.height = 1920;

    // Fond dégradé vertical haute qualité (Noir vers Violet sombre)
    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, '#0a0915');
    gradient.addColorStop(1, '#020105');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Boîte du message reçu (Style verre translucide)
    ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.beginPath();
    ctx.roundRect(100, 450, 880, 320, 40);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Texte d'en-tête du message
    ctx.fillStyle = '#f43f5e';
    ctx.font = 'bold 36px sans-serif';
    ctx.fillText('MESSAGE ANONYME : 🤫', 150, 520);

    // Contenu du message
    ctx.fillStyle = '#ffffff';
    ctx.font = '40px sans-serif';
    wrapCanvasText(ctx, activeMessage.content, 150, 600, 780, 55);

    // Boîte de réponse (Teinte violette)
    ctx.fillStyle = 'rgba(124, 58, 237, 0.15)';
    ctx.beginPath();
    ctx.roundRect(100, 820, 880, 320, 40);
    ctx.fill();
    ctx.strokeStyle = 'rgba(124, 58, 237, 0.3)';
    ctx.stroke();

    // En-tête de la réponse
    ctx.fillStyle = '#a78bfa';
    ctx.font = 'bold 36px sans-serif';
    ctx.fillText('MA RÉPONSE :', 150, 890);

    // Contenu de la réponse
    ctx.fillStyle = '#ffffff';
    ctx.font = '40px sans-serif';
    wrapCanvasText(ctx, replyText || 'Pas de réponse...', 150, 970, 780, 55);

    // Instructions de partage en bas de l'image
    ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.font = '32px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Pose-moi des questions anonymes sur mon profil !', canvas.width / 2, 1720);

    // Téléchargement du fichier PNG
    const link = document.createElement('a');
    link.download = `snapchat-reply-${activeMessage.id}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  // 1. Écran de connexion si non authentifié
  if (!user) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-[#07070F] text-white px-4">
        <div className="w-full max-w-md bg-neutral-900 border border-neutral-800/80 p-8 rounded-3xl shadow-2xl">
          <h2 className="text-2xl font-bold text-center mb-2">Bienvenue sur Secretly</h2>
          <p className="text-neutral-400 text-xs text-center mb-8">Crée un compte pour recevoir tes premiers secrets</p>
          
          <form onSubmit={handleAuth} className="space-y-4">
            <input
              type="email"
              placeholder="Adresse email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:ring-2 focus:ring-violet-600 text-sm"
              required
            />
            <input
              type="password"
              placeholder="Mot de passe"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:ring-2 focus:ring-violet-600 text-sm"
              required
            />
            <button
              type="submit"
              className="w-full py-3.5 bg-violet-600 rounded-xl hover:bg-violet-700 font-semibold transition text-sm shadow-lg shadow-violet-600/10"
            >
              {authMode === 'login' ? 'Connexion' : 'Créer mon compte'}
            </button>
          </form>

          <div className="text-center mt-6">
            <button
              onClick={() => setAuthMode(authMode === 'login' ? 'signup' : 'login')}
              className="text-xs text-neutral-400 hover:text-white transition underline"
            >
              {authMode === 'login' ? "Je n'ai pas de compte ? S'inscrire" : 'Déjà inscrit ? Me connecter'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 2. Écran du Dashboard principal s'il est connecté
  return (
    <div className="flex min-h-screen bg-[#07070F] text-white flex-col md:flex-row">
      <canvas ref={canvasRef} className="hidden" />

      {/* Colonne de gauche (Liste des messages) */}
      <div className="w-full md:w-5/12 lg:w-4/12 border-b md:border-b-0 md:border-r border-neutral-900 p-6 flex flex-col max-h-screen overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold tracking-tight">Ma boîte 📥</h1>
          <button 
            onClick={() => supabase.auth.signOut()} 
            className="text-xs text-neutral-400 hover:text-white bg-neutral-900/80 px-3.5 py-2 rounded-xl border border-neutral-800 transition"
          >
            Déconnexion
          </button>
        </div>

        {/* Lien de profil personnel à partager */}
        <div className="bg-neutral-900/60 border border-neutral-800 p-4 rounded-2xl mb-6 shadow-inner">
          <p className="text-xs text-neutral-400 mb-1.5 font-medium">Ton lien de profil à mettre en Story :</p>
          <div className="flex items-center justify-between gap-2">
            <code className="text-xs block bg-black/60 p-2.5 rounded-lg text-violet-400 overflow-x-auto select-all flex-1">
              {typeof window !== 'undefined' ? `${window.location.origin}/${user.id}` : ''}
            </code>
          </div>
        </div>

        {/* Liste des messages */}
        <div className="space-y-3 flex-1">
          {messages.length === 0 ? (
            <div className="text-center py-12 text-neutral-500">
              <span className="text-3xl block mb-2">📭</span>
              Aucun message pour le moment.<br />Partage ton lien ci-dessus !
            </div>
          ) : (
            messages.map((m) => (
              <div
                key={m.id}
                onClick={() => { setActiveMessage(m); setReplyText(''); }}
                className={`p-4 rounded-2xl cursor-pointer border transition ${
                  activeMessage?.id === m.id 
                    ? 'bg-violet-600/10 border-violet-600/50' 
                    : 'bg-neutral-900/40 border-neutral-900 hover:border-neutral-800/80'
                }`}
              >
                <p className="text-sm line-clamp-2 text-neutral-200">{m.content}</p>
                <span className="text-[10px] text-neutral-500 block mt-2">
                  {new Date(m.created_at).toLocaleDateString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Colonne de droite (Détail & Réponse) */}
      <div className="flex-1 p-6 md:p-12 flex flex-col justify-center items-center">
        {activeMessage ? (
          <div className="w-full max-w-xl bg-neutral-900/50 border border-neutral-800/80 p-6 md:p-8 rounded-3xl space-y-6 shadow-2xl backdrop-blur-sm">
            <div>
              <span className="text-xs text-violet-400 font-bold uppercase tracking-widest">Message Reçu</span>
              <p className="text-lg mt-2 bg-neutral-950 border border-neutral-800/80 p-5 rounded-2xl leading-relaxed">
                {activeMessage.content}
              </p>
            </div>

            <div>
              <span className="text-xs text-neutral-400 font-bold uppercase tracking-widest">Écrire ma réponse</span>
              <textarea
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Rédige ce que tu veux ajouter sur la Story..."
                maxLength={80}
                rows={3}
                className="w-full p-4 mt-2 rounded-2xl bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:ring-2 focus:ring-violet-600 resize-none text-sm transition"
              />
              <div className="text-right text-[10px] text-neutral-500 mt-1">
                {replyText.length}/80 caractères max
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={downloadSnapchatStory}
                className="flex-1 py-3.5 bg-yellow-400 text-black font-extrabold rounded-2xl hover:bg-yellow-300 transition text-sm shadow-lg shadow-yellow-400/5"
              >
                Générer pour Snapchat 📸
              </button>
              <button
                onClick={() => handleDelete(activeMessage.id)}
                className="px-6 py-3.5 bg-red-600/10 text-red-500 border border-red-500/20 rounded-2xl hover:bg-red-600 hover:text-white transition text-sm font-medium"
              >
                Supprimer
              </button>
            </div>
          </div>
        ) : (
          <div className="text-neutral-500 text-center select-none py-12 md:py-0">
            <span className="text-5xl block mb-4 animate-bounce">👈</span>
            <p className="font-medium text-sm">Sélectionne un message dans la liste de gauche pour y répondre.</p>
          </div>
        )}
      </div>
    </div>
  );
}
