'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export default function SendMessagePage({ params }: { params: { username: string } }) {
  const [recipientId, setRecipientId] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');

  // Récupérer l'ID de l'utilisateur à partir du pseudo (email avant le @ pour faire simple)
  useEffect(() => {
    async function getRecipient() {
      const { data, error } = await supabase
        .from('profiles') // Supabase auth expose parfois les emails, on cherche ici l'utilisateur correspondant
        .select('id')
        .ilike('username', params.username) // On assume que tu as lié un pseudo
        .single();
      
      // Alternative ultra-simple : on cherche via une table temporaire ou on passe l'ID directement.
      // Pour faire ultra simple sans table profile : on cherche l'ID utilisateur directement si tu le passes.
    }
    // Ici, pour simplifier au maximum, on suppose que l'URL contient directement l'UUID de l'utilisateur (ex: monsite.com/UUID)
    setRecipientId(params.username);
  }, [params.username]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !recipientId) return;

    setStatus('sending');
    const { error } = await supabase.from('messages').insert({
      recipient_id: recipientId,
      content: message,
    });

    if (error) {
      setStatus('error');
    } else {
      setStatus('success');
      setMessage('');
    }
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-neutral-950 text-white px-4">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 p-6 rounded-2xl shadow-xl">
        <div className="text-center mb-6">
          <div className="inline-block p-3 bg-violet-600 rounded-full mb-3">🤫</div>
          <h1 className="text-xl font-bold">Envoyer un message anonyme</h1>
          <p className="text-neutral-400 text-xs mt-1">L'utilisateur ne saura jamais qui tu es.</p>
        </div>

        {status === 'success' ? (
          <div className="text-center py-6">
            <p className="text-emerald-400 font-semibold mb-4">Message envoyé avec succès ! 🎉</p>
            <button 
              onClick={() => setStatus('idle')}
              className="text-sm bg-neutral-800 px-4 py-2 rounded-lg hover:bg-neutral-700 transition"
            >
              En envoyer un autre
            </button>
          </div>
        ) : (
          <form onSubmit={handleSend} className="space-y-4">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Écris ton message secret ici..."
              maxLength={250}
              required
              rows={4}
              className="w-full p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:ring-2 focus:ring-violet-600 resize-none text-sm"
            />
            <button
              type="submit"
              disabled={status === 'sending'}
              className="w-full py-3 bg-white text-black font-semibold rounded-xl hover:bg-neutral-200 transition disabled:opacity-50"
            >
              {status === 'sending' ? 'Envoi...' : 'Envoyer le message'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
